CREATE DATABASE IF NOT EXISTS hotel_booking_analytics;
USE hotel_booking_analytics;

-- Import the pipeline output CSV into a table named hotel_bookings
-- using MySQL Workbench: Server > Data Import (Table Data Import Wizard).
-- The wizard detects the columns and data types from the CSV.
