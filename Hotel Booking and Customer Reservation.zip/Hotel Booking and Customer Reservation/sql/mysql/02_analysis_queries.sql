USE hotel_booking_analytics;

SELECT COUNT(*) AS total_bookings,
       SUM(is_canceled = 1) AS canceled_bookings,
       ROUND(100 * AVG(is_canceled), 2) AS cancellation_rate_pct,
       ROUND(AVG(adr), 2) AS average_adr,
       ROUND(AVG(lead_time), 2) AS average_lead_time
FROM hotel_bookings;

SELECT hotel, COUNT(*) AS bookings,
       ROUND(100 * AVG(is_canceled), 2) AS cancellation_rate_pct,
       ROUND(AVG(adr), 2) AS average_adr
FROM hotel_bookings
GROUP BY hotel
ORDER BY bookings DESC;

SELECT market_segment, COUNT(*) AS bookings,
       ROUND(100 * AVG(is_canceled), 2) AS cancellation_rate_pct,
       ROUND(AVG(adr), 2) AS average_adr
FROM hotel_bookings
GROUP BY market_segment
ORDER BY bookings DESC;

SELECT arrival_year_month, COUNT(*) AS bookings
FROM hotel_bookings
GROUP BY arrival_year_month
ORDER BY arrival_year_month;

SELECT country, COUNT(*) AS bookings
FROM hotel_bookings
GROUP BY country
ORDER BY bookings DESC
LIMIT 10;
