# Data Dictionary and Analysis Notes

The supplied CSV has 87,396 rows and 36 columns. It includes the standard hotel booking fields plus derived fields.

## Main fields
- `hotel`: Resort Hotel or City Hotel.
- `is_canceled`: 1 = canceled, 0 = not canceled.
- `lead_time`: days between booking and arrival.
- `arrival_date_year`, `arrival_date_month`, `arrival_date_day_of_month`: planned arrival date parts.
- `stays_in_weekend_nights`, `stays_in_week_nights`: planned stay nights.
- `adults`, `children`, `babies`: guest counts.
- `country`: guest country code; missing values are represented as Unknown in the cleaned output.
- `market_segment`, `distribution_channel`: booking source/channel categories.
- `is_repeated_guest`: 1 = repeated guest, 0 = not repeated.
- `reserved_room_type`, `assigned_room_type`: reserved and assigned room categories.
- `deposit_type`: deposit policy category.
- `agent`, `company`: booking agent/company identifiers; missing means no recorded identifier.
- `adr`: average daily rate field in the source dataset.
- `reservation_status`: Check-Out, Canceled, or No-Show status.
- `reservation_status_date`: date of the latest status.
- `total_nights`: derived weekend nights + weekday nights (already supplied in this file).
- `arrival_month_number`, `arrival_year_month`: derived arrival period fields.
- `estimated_room_revenue`: estimated amount supplied in this dataset; not audited cash revenue.

## Data quality
- The supplied data file has no exact duplicate rows.
- `agent` and `company` contain many missing values. They are intentionally preserved.
- Occupancy cannot be measured without the number of rooms available and the dates each room was available.
