# Hotel Booking and Customer Reservation Project

A complete beginner-friendly analytics project using the supplied hotel booking dataset.

## Dataset included
- File: `data/cleaned_bookings.csv`
- Rows: 87,396
- Columns: 36
- Exact duplicate rows in the supplied file: 0
- This is the dataset uploaded for this project, not a live data feed.

## Project workflow
1. Load and validate the dataset.
2. Explore shape, columns, data types, missing values, duplicates and summary statistics.
3. Clean selected fields while preserving meaningful unknown IDs.
4. Create business KPIs and analysis tables.
5. Generate charts and CSV reports.
6. Load the cleaned data into a local SQLite database.
7. Optionally load the data into MySQL Workbench.
8. Build a Power BI dashboard using the included measures and guide.

## Important data-quality decisions
- Missing `agent` and `company` values are retained as missing. These are identifiers, and replacing missing IDs with zero can falsely imply a real agent/company ID.
- Missing `country` is labelled `Unknown`.
- Missing `children` is filled with 0, as a missing count is treated as no children for this project. Review this assumption before using the result for formal reporting.
- Date fields are parsed with invalid values coerced to missing dates.
- Exact duplicate rows are removed. No other rows are removed automatically.
- `estimated_room_revenue` is an estimate already present in the supplied data. It is not audited cash revenue and must not be described as actual collected revenue.
- The dataset does not contain room inventory/capacity, so true occupancy rate cannot be calculated from this dataset alone.
- The dataset is historical/static; it does not update automatically.

## Requirements
- Python 3.10 or newer
- Jupyter Notebook (optional, for the notebook workflow)

## Setup on Windows PowerShell
Open PowerShell in this project folder:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell blocks activation, use `python -m pip install -r requirements.txt` without activating the environment.

## Run the complete pipeline
```powershell
python run_project.py
```

The script creates:
- `outputs/reports/cleaned_bookings.csv`
- `outputs/reports/data_quality_report.csv`
- `outputs/reports/kpi_summary.csv`
- `outputs/reports/monthly_analysis.csv`
- `outputs/reports/hotel_analysis.csv`
- `outputs/reports/market_segment_analysis.csv`
- `outputs/reports/top_countries.csv`
- `outputs/reports/hotel_bookings.sqlite`
- `outputs/charts/*.png`

## Run in Jupyter
1. Open `notebooks/Hotel_Booking_Analysis.ipynb`.
2. Select the project root as the working directory, or use the notebook's path-detection cell.
3. Run all cells from top to bottom.

## SQLite
The pipeline creates a local SQLite database automatically. No database server or password is required.
The SQL analysis queries are in `sql/sqlite/analysis_queries.sql`.

## Optional MySQL Workbench
1. Create a database using `sql/mysql/01_create_database.sql`.
2. Import `outputs/reports/cleaned_bookings.csv` with MySQL Workbench's Table Data Import Wizard, or use the supplied Python loader:
   `python src/load_to_mysql.py --host localhost --user root --database hotel_booking_analytics`
3. The loader prompts for the MySQL password; do not put passwords in source files.
4. Run `sql/mysql/02_analysis_queries.sql`.

Install optional MySQL connector:
```powershell
python -m pip install mysql-connector-python
```

## Power BI
Use `outputs/reports/cleaned_bookings.csv` as the data source. Follow `power_bi/DASHBOARD_GUIDE.md` and import measures from `power_bi/DAX_Measures.dax`.

## Suggested dashboard pages
- Executive Overview: bookings, cancellation rate, average ADR, estimated room revenue
- Booking Trends: arrivals by month, hotel type, lead time
- Customer & Channels: market segment, distribution channel, customer type, top countries
- Operations: special requests, parking requests, booking changes

## Project limitations
The analysis is descriptive, not predictive. No forecasting or machine-learning model is included. The project is designed to be reproducible and understandable for a beginner portfolio.
