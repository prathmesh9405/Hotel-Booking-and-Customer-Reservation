# Power BI Dashboard Guide

## Load data
1. Run `python run_project.py`.
2. Open Power BI Desktop.
3. Get Data > Text/CSV.
4. Select `outputs/reports/cleaned_bookings.csv`.
5. Confirm date and numeric data types in Power Query.
6. Rename the query/table to `hotel_bookings` to match the supplied DAX measures.

## Page 1 — Executive Overview
- Cards: Total Bookings, Canceled Bookings, Cancellation Rate, Average ADR, Estimated Room Revenue.
- Bar chart: Bookings by hotel.
- Line chart: Bookings by arrival year-month.
- Slicers: hotel, arrival_date_year, market_segment, country.

## Page 2 — Cancellation Analysis
- Bar chart: cancellation rate by hotel.
- Bar chart: cancellation rate by market segment.
- Column chart: cancellations by lead-time band (create bins in Power BI).
- Slicers: deposit_type, customer_type, distribution_channel.

## Page 3 — Customer & Channel Analysis
- Bar chart: bookings by market segment.
- Bar chart: top 10 countries.
- Donut or bar chart: repeated vs new guests.
- Matrix: hotel by customer_type.

## Page 4 — Booking Operations
- Cards: Average Stay Nights, Average Lead Time, Repeated Guest Bookings.
- Bar chart: special requests.
- Bar chart: required car parking spaces.
- Table: hotel, room types, booking changes, reservation status.

## Important
Estimated room revenue is an estimate, not verified cash collected. Do not create an occupancy-rate KPI because the dataset has no room inventory/capacity field.
