"""Reusable hotel booking analysis pipeline."""
from pathlib import Path
import sqlite3
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

REQUIRED_COLUMNS = {
    "hotel", "is_canceled", "lead_time", "adr",
    "arrival_date_year", "arrival_date_month",
    "stays_in_weekend_nights", "stays_in_week_nights"
}

MONTH_ORDER = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
]

def load_data(csv_path):
    csv_path = Path(csv_path)
    if not csv_path.exists():
        raise FileNotFoundError(f"Dataset not found: {csv_path}")
    df = pd.read_csv(csv_path)
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")
    return df

def clean_data(df):
    """Clean conservatively; do not fabricate agent/company IDs."""
    clean = df.copy()
    clean = clean.drop_duplicates().copy()

    if "country" in clean.columns:
        clean["country"] = clean["country"].fillna("Unknown")

    if "children" in clean.columns:
        clean["children"] = clean["children"].fillna(0)

    if "reservation_status_date" in clean.columns:
        clean["reservation_status_date"] = pd.to_datetime(
            clean["reservation_status_date"], errors="coerce"
        )

    # Ensure core numeric columns are numeric
    numeric_columns = [
        "is_canceled", "lead_time", "adr", "arrival_date_year",
        "stays_in_weekend_nights", "stays_in_week_nights"
    ]
    for col in numeric_columns:
        if col in clean.columns:
            clean[col] = pd.to_numeric(clean[col], errors="coerce")

    if "total_nights" not in clean.columns:
        clean["total_nights"] = (
            clean["stays_in_weekend_nights"].fillna(0)
            + clean["stays_in_week_nights"].fillna(0)
        )

    if "arrival_month_number" not in clean.columns and "arrival_date_month" in clean.columns:
        month_map = {name: i for i, name in enumerate(MONTH_ORDER, start=1)}
        clean["arrival_month_number"] = clean["arrival_date_month"].map(month_map)

    if "arrival_year_month" not in clean.columns and {
        "arrival_date_year", "arrival_month_number"
    }.issubset(clean.columns):
        clean["arrival_year_month"] = (
            clean["arrival_date_year"].astype("Int64").astype(str)
            + "-"
            + clean["arrival_month_number"].astype("Int64").astype(str).str.zfill(2)
        )

    # Estimate only if the source dataset does not already supply the field.
    if "estimated_room_revenue" not in clean.columns and {"adr", "total_nights"}.issubset(clean.columns):
        clean["estimated_room_revenue"] = clean["adr"] * clean["total_nights"]

    return clean

def make_reports(df, output_dir):
    output_dir = Path(output_dir)
    reports = output_dir / "reports"
    charts = output_dir / "charts"
    reports.mkdir(parents=True, exist_ok=True)
    charts.mkdir(parents=True, exist_ok=True)

    data_quality = pd.DataFrame({
        "column": df.columns,
        "dtype": [str(df[c].dtype) for c in df.columns],
        "missing_count": [int(df[c].isna().sum()) for c in df.columns],
        "missing_percent": [round(float(df[c].isna().mean() * 100), 2) for c in df.columns],
        "unique_values": [int(df[c].nunique(dropna=True)) for c in df.columns],
    })
    data_quality.to_csv(reports / "data_quality_report.csv", index=False)

    total = len(df)
    canceled = int((df["is_canceled"] == 1).sum())
    kpis = [
        ("Total bookings", total),
        ("Canceled bookings", canceled),
        ("Non-canceled bookings", int((df["is_canceled"] == 0).sum())),
        ("Cancellation rate (%)", round(canceled / total * 100, 2) if total else 0),
        ("Average lead time (days)", round(float(df["lead_time"].mean()), 2)),
        ("Average ADR", round(float(df["adr"].mean()), 2)),
        ("Estimated room revenue", round(float(df["estimated_room_revenue"].sum()), 2)
         if "estimated_room_revenue" in df.columns else np.nan),
        ("Average total nights", round(float(df["total_nights"].mean()), 2)),
    ]
    pd.DataFrame(kpis, columns=["KPI", "Value"]).to_csv(reports / "kpi_summary.csv", index=False)

    hotel_analysis = df.groupby("hotel", dropna=False).agg(
        bookings=("hotel", "size"),
        cancellation_rate=("is_canceled", "mean"),
        average_adr=("adr", "mean"),
        average_lead_time=("lead_time", "mean"),
    ).reset_index()
    hotel_analysis["cancellation_rate"] = (hotel_analysis["cancellation_rate"] * 100).round(2)
    hotel_analysis.to_csv(reports / "hotel_analysis.csv", index=False)

    if "market_segment" in df.columns:
        market = df.groupby("market_segment", dropna=False).agg(
            bookings=("market_segment", "size"),
            cancellation_rate=("is_canceled", "mean"),
            average_adr=("adr", "mean"),
        ).reset_index()
        market["cancellation_rate"] = (market["cancellation_rate"] * 100).round(2)
        market.to_csv(reports / "market_segment_analysis.csv", index=False)

    if "country" in df.columns:
        df["country"].value_counts(dropna=False).head(15).rename_axis("country").reset_index(
            name="bookings"
        ).to_csv(reports / "top_countries.csv", index=False)

    if "arrival_year_month" in df.columns:
        monthly = df.groupby("arrival_year_month", dropna=False).agg(
            bookings=("arrival_year_month", "size"),
            cancellation_rate=("is_canceled", "mean"),
            average_adr=("adr", "mean"),
        ).reset_index()
        monthly["cancellation_rate"] = (monthly["cancellation_rate"] * 100).round(2)
        monthly.to_csv(reports / "monthly_analysis.csv", index=False)

    # Charts
    def save_bar(series, title, xlabel, ylabel, filename, rotate=0):
        fig, ax = plt.subplots(figsize=(10, 5))
        series.plot(kind="bar", ax=ax)
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.tick_params(axis="x", labelrotation=rotate)
        fig.tight_layout()
        fig.savefig(charts / filename, dpi=150)
        plt.close(fig)

    save_bar(df["hotel"].value_counts(), "Bookings by Hotel Type", "Hotel", "Bookings",
             "bookings_by_hotel.png")

    cancel_by_hotel = (df.groupby("hotel")["is_canceled"].mean() * 100).round(2)
    save_bar(cancel_by_hotel, "Cancellation Rate by Hotel Type", "Hotel", "Cancellation rate (%)",
             "cancellation_rate_by_hotel.png")

    if "market_segment" in df.columns:
        save_bar(df["market_segment"].value_counts().head(10), "Bookings by Market Segment",
                 "Market segment", "Bookings", "bookings_by_market_segment.png", 35)

    if "arrival_year_month" in df.columns:
        monthly_counts = df["arrival_year_month"].value_counts().sort_index()
        fig, ax = plt.subplots(figsize=(12, 5))
        monthly_counts.plot(kind="line", marker="o", ax=ax)
        ax.set_title("Bookings by Arrival Year-Month")
        ax.set_xlabel("Arrival year-month")
        ax.set_ylabel("Bookings")
        ax.tick_params(axis="x", labelrotation=60)
        fig.tight_layout()
        fig.savefig(charts / "bookings_over_time.png", dpi=150)
        plt.close(fig)

    if "lead_time" in df.columns:
        fig, ax = plt.subplots(figsize=(9, 5))
        df["lead_time"].clip(upper=df["lead_time"].quantile(0.99)).plot(
            kind="hist", bins=30, ax=ax
        )
        ax.set_title("Lead Time Distribution (capped at 99th percentile)")
        ax.set_xlabel("Lead time (days)")
        ax.set_ylabel("Number of bookings")
        fig.tight_layout()
        fig.savefig(charts / "lead_time_distribution.png", dpi=150)
        plt.close(fig)

def save_sqlite(df, db_path):
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    # SQLite stores dates as text for portability.
    export_df = df.copy()
    for col in export_df.columns:
        if pd.api.types.is_datetime64_any_dtype(export_df[col]):
            export_df[col] = export_df[col].dt.strftime("%Y-%m-%d")
    with sqlite3.connect(db_path) as conn:
        export_df.to_sql("hotel_bookings", conn, if_exists="replace", index=False)

def run_pipeline(input_csv, output_dir):
    raw = load_data(input_csv)
    cleaned = clean_data(raw)
    output_dir = Path(output_dir)
    reports = output_dir / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    cleaned.to_csv(reports / "cleaned_bookings.csv", index=False)
    make_reports(cleaned, output_dir)
    save_sqlite(cleaned, reports / "hotel_bookings.sqlite")
    print("PIPELINE COMPLETED")
    print(f"Input rows: {len(raw):,}")
    print(f"Output rows: {len(cleaned):,}")
    print(f"Columns: {len(cleaned.columns)}")
    print(f"Output folder: {output_dir.resolve()}")
    print("Note: agent/company missing IDs were intentionally preserved.")
