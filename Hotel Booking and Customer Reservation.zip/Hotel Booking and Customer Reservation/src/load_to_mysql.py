"""Optional MySQL loader. Install mysql-connector-python first."""
import argparse
from pathlib import Path
import getpass
import pandas as pd

def mysql_type(series):
    if pd.api.types.is_integer_dtype(series):
        return "BIGINT"
    if pd.api.types.is_float_dtype(series):
        return "DOUBLE"
    return "TEXT"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=3306)
    parser.add_argument("--user", default="root")
    parser.add_argument("--database", default="hotel_booking_analytics")
    parser.add_argument("--csv", default="outputs/reports/cleaned_bookings.csv")
    args = parser.parse_args()

    try:
        import mysql.connector
    except ImportError:
        raise SystemExit("Install connector first: python -m pip install mysql-connector-python")

    csv_path = Path(args.csv)
    if not csv_path.exists():
        raise SystemExit(f"CSV not found: {csv_path}. Run python run_project.py first.")

    password = getpass.getpass("MySQL password: ")
    df = pd.read_csv(csv_path)
    conn = mysql.connector.connect(
        host=args.host, port=args.port, user=args.user,
        password=password, database=args.database
    )
    cursor = conn.cursor()

    definitions = []
    for col in df.columns:
        definitions.append(f"`{col}` {mysql_type(df[col])} NULL")
    cursor.execute(
        "CREATE TABLE hotel_bookings (" + ", ".join(definitions) + ")"
    )
    placeholders = ", ".join(["%s"] * len(df.columns))
    column_names = ", ".join(f"`{c}`" for c in df.columns)
    insert_sql = f"INSERT INTO hotel_bookings ({column_names}) VALUES ({placeholders})"

    rows = []
    for row in df.itertuples(index=False, name=None):
        values = [None if pd.isna(v) else v.item() if hasattr(v, "item") else v for v in row]
        rows.append(tuple(values))
        if len(rows) >= 1000:
            cursor.executemany(insert_sql, rows)
            rows.clear()
    if rows:
        cursor.executemany(insert_sql, rows)

    conn.commit()
    cursor.execute("SELECT COUNT(*) FROM hotel_bookings")
    print("Rows loaded:", cursor.fetchone()[0])
    cursor.close()
    conn.close()

if __name__ == "__main__":
    main()
