from pathlib import Path
import sys
import unittest
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from hotel_analysis import load_data, clean_data

class HotelPipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = load_data(ROOT / "data" / "cleaned_bookings.csv")
        cls.clean = clean_data(cls.raw)

    def test_dataset_has_expected_rows(self):
        self.assertEqual(len(self.raw), 87396)

    def test_required_columns_exist(self):
        self.assertIn("hotel", self.raw.columns)
        self.assertIn("is_canceled", self.raw.columns)

    def test_cleaning_removes_duplicates(self):
        self.assertEqual(self.clean.duplicated().sum(), 0)

    def test_missing_agent_ids_are_not_fabricated(self):
        if "agent" in self.raw.columns:
            self.assertEqual(self.clean["agent"].isna().sum(), self.raw["agent"].isna().sum())

    def test_derived_columns_exist(self):
        self.assertIn("total_nights", self.clean.columns)
        self.assertIn("estimated_room_revenue", self.clean.columns)

if __name__ == "__main__":
    unittest.main()
